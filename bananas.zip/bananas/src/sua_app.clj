(ns sua-app
  (:require [clj-http.client :as http-client]
            [cheshire.core :as json]))

(def chave "h6PQv7nGo28jwg7UiePTEU")
(def api-url "https://brapi.dev/api/quote/")

;; Função para obter dados de cotação de ação
(defn obter-cotacao [codigo]
  (let [response (http-client/get (str api-url codigo "?token=" chave))]
    (if (= 200 (:status response))
      (json/parse-string (:body response) true)
      (do
        (println (str "Erro na requisição: " (:status response)))
        nil))))

(defn exibir-lista-companhias []
  (println "Lista de Companhias Cotadas na B3:")
  (let [response (http-client/get (str api-url "list?token=" chave))]
    (if (= 200 (:status response))
      (do
        (println "Resposta da API:")
        (println (:body response)) ;; Adiciona esta linha para ver o corpo da resposta da API
        (let [body (json/parse-string (:body response) true)]
          (println "Estrutura da Resposta Parseada:")
          (println body) ;; Adiciona esta linha para ver a estrutura da resposta parseada
          (do
            (let [companies (take 1 (get-in body [:data :companies]))]
              (doseq [company companies]
                (println (str (:symbol company) " - " (:name company)))
                ;; Adicione mais informações específicas da empresa aqui, se necessário.
                )))))
      (do
        (println (str "Erro na requisição: " (:status response)))
        nil))))




;; Função para exibir os dados de uma ação escolhida
(defn exibir-dados-acao [codigo]
  (let [cotacao (obter-cotacao codigo)]
    (if cotacao
      (do
        (println (str "Dados da Ação " codigo ":"))
        (println (str "Nome: " (:longName (first (:results cotacao)))))
        (println (str "Código: " (:symbol (first (:results cotacao)))))
        (println (str "Tipo de Ativo: " (:currency (first (:results cotacao)))))
        (println (str "Descrição: " (:shortName (first (:results cotacao)))))
        (println (str "Variação do Dia (R$): " (:regularMarketChange (first (:results cotacao)))))
        (println (str "Variação do Dia (%): " (:regularMarketChangePercent (first (:results cotacao)))))
        (println (str "Último Preço: " (:regularMarketPrice (first (:results cotacao)))))
        (println (str "Preço Máximo: " (:regularMarketDayHigh (first (:results cotacao)))))
        (println (str "Preço Mínimo: " (:regularMarketDayLow (first (:results cotacao)))))
        (println (str "Preço de Abertura: " (:regularMarketOpen (first (:results cotacao)))))
        (println (str "Preço de Fechamento: " (:regularMarketPreviousClose (first (:results cotacao)))))
        (println (str "Hora: " (:regularMarketTime (first (:results cotacao)))))
        )
      (println (str "Ação não encontrada: " codigo)))))

;; Exemplo de uso
(exibir-lista-companhias)
(exibir-dados-acao "PETR4")
