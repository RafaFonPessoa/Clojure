(ns api
  (:require [clj-http.client :as http-client]
            [cheshire.core :as json]))

(def api-url "https://brapi.dev/api/quote/")
(def chave "h6PQv7nGo28jwg7UiePTEU")

;; Átomo para armazenar as transações
(def transacoes (atom []))

;;Obtem o Json da API
(defn obter-cotacao [codigo]
  (let [url (str api-url codigo "?token=" chave)
        response (http-client/get url)]
    (if (= 200 (:status response))
      (json/parse-string (:body response) true)
      (do
        (println (str "Erro na requisição: " (:status response)))
        nil))))

;; 1)
(defn exibir-lista-companhias []
  (let [url (str api-url "list?token=" chave)
        response (http-client/get url)]
    (if (= 200 (:status response))
      (do
        (println "Lista de Companhias Cotadas:")
        (let [data (json/parse-string (:body response) true)
              indexes (get-in data [:indexes])
              stocks (get-in data [:stocks])]
          (doseq [index indexes]
            (println (str (:stock index) " - " (:name index))))
          (doseq [stock stocks]
            (println (str (:stock stock) " - " (:name stock))))))
      (println (str "Erro na requisição: " (:status response))))))

;;2)
(defn exibir-dados-acao [codigo]
  (let [cotacao (obter-cotacao codigo)]
    (if cotacao
      (let [results (:results cotacao)]
        (if (seq results)
          (do
            (println (str "Dados da Ação " codigo ":"))
            (println (str "Nome: " (:longName (first results))))
            (println (str "Código: " (:symbol (first results))))
            (println (str "Moeda: " (:currency (first results))))
            (println (str "Descrição: " (:shortName (first results))))
            (println (str "Variação do Dia (R$): " (:regularMarketChange (first results))))
            (println (str "Variação do Dia (%): " (:regularMarketChangePercent (first results))))
            (println (str "Último Preço: " (:regularMarketPrice (first results))))
            (println (str "Preço Máximo: " (:regularMarketDayHigh (first results))))
            (println (str "Preço Mínimo: " (:regularMarketDayLow (first results))))
            (println (str "Preço de Abertura: " (:regularMarketOpen (first results))))
            (println (str "Preço de Fechamento: " (:regularMarketPreviousClose (first results))))
            (println (str "Hora: " (:regularMarketTime (first results))))
            (println "")))))))

;;3)
(defn registrar-compra [codigo quantidade valor]
  (swap! transacoes conj {:tipo :compra :codigo codigo :quantidade quantidade :valor (* valor quantidade) :data (java.util.Date.)})
  (println "Compra concluída com sucesso."))

;; 4)
(defn registrar-venda [codigo quantidade]
  (let [acoes-compradas (filter #(and (= codigo (:codigo %)) (= :compra (:tipo %))) @transacoes)
        acoes-vendidas (filter #(and (= codigo (:codigo %)) (= :venda (:tipo %))) @transacoes)
        quantidade-comprada (reduce + (map :quantidade acoes-compradas))
        quantidade-vendida (reduce + (map :quantidade acoes-vendidas))
        quantidade-disponivel (- quantidade-comprada quantidade-vendida)
        cotacao (obter-cotacao codigo)
        valor (if cotacao (:regularMarketPrice (first (:results cotacao))))]

    (cond (> quantidade quantidade-disponivel)
          (println "Não foi possível fazer a venda. Quantidade insuficiente.")
          :else (do
                  (swap! transacoes conj {:tipo :venda :codigo codigo :quantidade quantidade :valor (* valor quantidade) :data (java.util.Date.)})
                  (println "Venda registrada com sucesso.")))))

;; 6)
(defn exibir-transacoes-tipo [tipo]
  (let [transacoes-tipo (filter #(= (keyword tipo) (:tipo %)) @transacoes)]
    (if (seq transacoes-tipo)
      (doseq [transacao transacoes-tipo]
        (println (str "Código: " (:codigo transacao) ", Quantidade: " (:quantidade transacao) ", Valor: " (format "%.2f" (:valor transacao)) ", Data: " (:data transacao))))
      (println (str "Nenhuma transação encontrada.")))))


;; 7)
(defn exibir-saldo-total []
  (let [compra (filter #(= :compra (:tipo %)) @transacoes)
        venda (filter #(= :venda (:tipo %)) @transacoes)]
    (println (str "Saldo Total da Carteira: " (- (apply + (map :valor compra)) (apply + (map :valor venda)))))))

;; 5)
(defn exibir-extrato-completo []
  (do
    (println "Transações de Compra:")
    (exibir-transacoes-tipo :compra)
    (println "")
    (println "Transações de Venda:")
    (exibir-transacoes-tipo :venda)))