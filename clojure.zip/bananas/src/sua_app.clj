(ns sua-app
  (:require [clj-http.client :as http-client]
            [cheshire.core :as json]))

(def chave "h6PQv7nGo28jwg7UiePTEU")
(def api-url "https://brapi.dev/api/quote/")

;; Função para obter dados de cotação de ação
(defn obter-cotacao [codigo]
  (let [response (http-client/get (str api-url codigo "?token=" chave))
        body (json/parse-string (:body response) true)]
    body))

;; Exemplo de uso
(let [cotacao-petr4 (obter-cotacao "PETR4")]
  (println "Cotação PETR4:")
  (println (str "Código: " (:symbol cotacao-petr4)))
  (println (str "Preço: " (:price cotacao-petr4)))
  (println (str "Variação: " (:change cotacao-petr4)))
  (println (str "Porcentagem de Variação: " (:changePercent cotacao-petr4)))
  (println (str "Última Atualização: " (:latestUpdate cotacao-petr4))))
