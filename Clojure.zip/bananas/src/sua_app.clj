(ns sua-app
  (:require [clj-http.client :as http-client]
            [cheshire.core :as json]))

(def chave "h6PQv7nGo28jwg7UiePTEU")
(def api-url "https://brapi.dev/api/quote/")

;; Função para obter dados de cotação de ação
(defn obter-cotacao [codigo]
  (let [response (http-client/get (str api-url codigo "?token=" chave))
        body (json/parse-string (:body response) true)]
    body))

;; Função para exibir a lista de companhias
(defn exibir-lista-companhias []
  (println "Lista de Companhias Cotadas na B3:")
  ;; Aqui você pode obter a lista de companhias disponíveis na API
  ;; e exibir os nomes ou códigos, por exemplo.
  ;; Certifique-se de tratar os dados da resposta JSON adequadamente.
  (println "1. PETR4 - Petrobras")
  (println "2. VALE3 - Vale SA")
  ;; Adicione mais companhias conforme necessário.
  )

;; Função para exibir os dados de uma ação escolhida
(defn exibir-dados-acao [codigo]
  (let [cotacao (obter-cotacao codigo)]
    (if cotacao
      (do
        (println (str "Dados da Ação " codigo ":"))
        (println (str "Nome: " (:longName cotacao)))
        (println (str "Código: " (:symbol cotacao)))
        (println (str "Tipo de Ativo: " (:type cotacao)))
        (println (str "Descrição: " (:shortName cotacao)))
        (println (str "Variação do Dia (R$): " (:regularMarketChange cotacao)))
        (println (str "Variação do Dia (%): " (:regularMarketChangePercent cotacao)))
        (println (str "Último Preço: " (:regularMarketPrice cotacao)))
        (println (str "Preço Máximo: " (:regularMarketDayHigh cotacao)))
        (println (str "Preço Mínimo: " (:regularMarketDayLow cotacao)))
        (println (str "Preço de Abertura: " (:regularMarketOpen cotacao)))
        (println (str "Preço de Fechamento: " (:regularMarketPreviousClose cotacao)))
        (println (str "Hora: " (:regularMarketTime cotacao)))
        )
      (println (str "Ação não encontrada: " codigo)))))

;; Exemplo de uso
(exibir-lista-companhias)
(exibir-dados-acao "PETR4")
